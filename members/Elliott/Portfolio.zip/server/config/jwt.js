module.exports = {
	TOKEN_SECRET: 'MY_SECRET'
};