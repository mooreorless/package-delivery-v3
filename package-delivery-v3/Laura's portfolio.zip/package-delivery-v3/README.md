# package-delivery-v3

## Build process
- Clone repo
Whilst in repo:
    - Run ```npm i```
    - Install git flow [Guide](http://danielkummer.github.io/git-flow-cheatsheet/)
    - Enable git flow ```git flow init``` 

Make your own branch
```git flow feature start "branch-name" ```

Run:
- ```npm run dev```

https://onthespot-production.herokuapp.com
